import { BookOpen, Calculator, Landmark, MapPin, Phone } from "lucide-react";
import { pricing, site } from "@/content/site";
import { CtaButton, PhoneLink } from "../ui/CtaButton";
import { Circled, Loop, Squiggle } from "../ui/Decor";
import { MetroIcon } from "../ui/MetroIcon";
import { ExamDeck } from "./ExamDeck";

const points = [
  "Отсутствие телефонов, рассадка по одному и точный тайминг",
  "Настоящие бланки и задания с учётом всех нововведений",
  "Проверка действующим экспертом и разбор каждой ошибки",
];

// плавающие теги предметов вокруг бланка, как языковые «флажки» в референсе
const tags = [
  { label: "Математика", icon: Calculator, pos: "left-0 top-[12%] hidden sm:flex sm:left-[2%]", tilt: "-8deg", delay: "0s" },
  { label: "Русский язык", icon: BookOpen, pos: "right-0 top-[4%] sm:right-[6%]", tilt: "7deg", delay: "1.2s" },
  { label: "История", icon: Landmark, pos: "left-[2%] bottom-[16%] hidden sm:flex", tilt: "-5deg", delay: "2.1s" },
];

export function Hero() {
  return (
    <section id="top" className="px-3 pt-24 sm:px-5 sm:pt-28">
      <div className="island-violet relative mx-auto max-w-[1360px] overflow-hidden rounded-[32px] text-white sm:rounded-[44px]">
        {/* декор */}
        <Loop className="absolute -top-6 right-[38%] hidden w-56 opacity-60 lg:block" color="rgba(203,190,255,0.55)" />
        <Squiggle className="absolute -bottom-10 -left-6 w-20 opacity-90 sm:w-28" />

        <div className="relative grid gap-8 px-5 pt-8 sm:px-10 sm:pt-12 lg:grid-cols-[1.05fr_0.95fr] lg:gap-4 lg:px-14 lg:pt-16">
          <div className="pb-2 lg:pb-16">
            <div className="flex flex-wrap items-center gap-2.5">
              <p className="inline-flex items-center gap-2.5 rounded-full bg-ink/25 py-1 pr-4 pl-1 ring-1 ring-white/15">
                <span className="rounded-full bg-lime px-3.5 py-1.5 font-display text-sm font-bold tracking-wide text-ink uppercase">
                  Очно
                </span>
                <span className="text-sm text-white/85">
                  в аудитории центра, а&nbsp;не&nbsp;<s className="pen-strike text-white/50">онлайн</s>
                </span>
              </p>
              <p className="inline-flex items-center gap-2.5 rounded-full bg-white/10 py-1 pr-4 pl-1 ring-1 ring-white/15">
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-white text-violet">
                  <MapPin size={16} strokeWidth={2.4} />
                </span>
                <span className="text-sm leading-tight">
                  <b className="font-semibold">{site.landmark}</b>
                  <span className="flex items-center gap-1.5 text-xs text-white/70">
                    <MetroIcon className="size-3.5" />
                    {site.metroName}, {site.metroWalk}
                  </span>
                </span>
              </p>
            </div>

            <h1 className="mt-7 text-[2.7rem] leading-[0.98] font-semibold sm:text-7xl xl:text-[5.4rem]">
              Пробный ЕГЭ
              <br />
              и ОГЭ как <Circled>настоящий</Circled>
            </h1>

            <p className="mt-7 max-w-xl text-lg text-pretty text-white/80 sm:text-xl">
              Приходи в центр и напиши любой предмет в условиях реального экзамена. Узнай свои баллы заранее и сдай ЕГЭ
              и ОГЭ без страха.
            </p>

            <ul className="mt-6 grid gap-2.5">
              {points.map((p) => (
                <li key={p} className="flex items-start gap-3 text-white/90">
                  <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-lime text-ink">
                    <svg viewBox="0 0 24 24" className="size-3.5" aria-hidden>
                      <path d="M4 13 L10 18 L20 5" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  {p}
                </li>
              ))}
            </ul>

            <div className="mt-9 flex flex-col gap-4 sm:flex-row sm:items-center">
              <CtaButton source="hero">Записаться на пробник</CtaButton>
              <div className="flex items-center gap-3 pl-1">
                <span className="grid size-11 place-items-center rounded-full bg-white/10 ring-1 ring-white/20">
                  <Phone size={18} />
                </span>
                <span className="leading-tight">
                  <span className="block text-xs text-white/60">или позвони</span>
                  <PhoneLink withIcon={false} className="font-display font-semibold" />
                </span>
              </div>
            </div>
          </div>

          {/* бланк на лаймовом круге: стопка «листов КИМ», живой бланк и стеклянные карточки */}
          <div className="relative flex min-h-[480px] items-center justify-center pb-10 sm:min-h-[560px] lg:pb-16">
            <div className="absolute top-1/2 left-1/2 aspect-square w-[118%] max-w-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-lime sm:w-[90%]" aria-hidden />

            <div className="relative scale-[0.9] sm:scale-110 lg:scale-[1.15]">
              {/* листы под бланком */}
              <div className="absolute inset-0 translate-x-7 translate-y-4 rotate-[8deg] rounded-[26px] bg-violet-deep" aria-hidden />
              <div className="absolute inset-0 -translate-x-6 translate-y-2 -rotate-[6deg] rounded-[26px] bg-lavender" aria-hidden />
              <ExamDeck className="relative" />
            </div>

            {tags.map((t) => (
              <span
                key={t.label}
                className={`float-tag absolute z-10 flex items-center gap-2 rounded-full bg-white py-1.5 pr-4 pl-1.5 text-sm font-semibold text-ink shadow-[0_14px_30px_-14px_rgba(24,19,47,0.6)] ${t.pos}`}
                style={{ "--tilt": t.tilt, animationDelay: t.delay } as React.CSSProperties}
              >
                <span className="grid size-7 place-items-center rounded-full bg-violet text-lime">
                  <t.icon size={15} />
                </span>
                {t.label}
              </span>
            ))}

            <div className="absolute right-0 bottom-6 z-20 hidden rounded-3xl bg-white/15 p-4 sm:block ring-1 ring-white/30 backdrop-blur-md sm:bottom-10 lg:right-2">
              <p className="font-display text-3xl leading-none font-semibold sm:text-4xl">
                {pricing.price.toLocaleString("ru-RU")}&nbsp;₽
              </p>
              <p className="mt-1.5 text-sm text-white/80">за один пробный экзамен</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
