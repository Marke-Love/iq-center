"use client";

import { useEffect, useRef, useState } from "react";
import { examDeck } from "@/content/site";

// «3 ч 55 мин» → секунды
function durationToSeconds(duration: string) {
  const h = Number(duration.match(/(\d+)\s*ч/)?.[1] ?? 0);
  const m = Number(duration.match(/(\d+)\s*мин/)?.[1] ?? 0);
  return h * 3600 + m * 60;
}

function format(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h}:${String(m).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

// Карточка «живёт» только на экране и при активной вкладке, иначе зря греет процессор
function useOnScreen<T extends HTMLElement>(ref: React.RefObject<T | null>) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting));
    io.observe(el);
    const onVisibility = () => setVisible(!document.hidden && el.getBoundingClientRect().bottom > 0);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      io.disconnect();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [ref]);
  return visible;
}

const ROWS = 4;
const CELLS = 6;

/*
  Компактный «живой» бланк ответов: стеклянная карточка поверх фото на первом экране.
  Ответы вписываются в клетки, эксперт ставит отметки, предметы сменяют друг друга.
*/
export function ExamDeck({ className = "" }: { className?: string }) {
  const rootRef = useRef<HTMLDivElement>(null);
  const onScreen = useOnScreen(rootRef);
  const [front, setFront] = useState(0);
  const [step, setStep] = useState(0);
  const [seconds, setSeconds] = useState(() => durationToSeconds(examDeck[0].duration));
  const frontRef = useRef(0);
  const blank = examDeck[front];
  const answers = blank.answers.slice(0, ROWS);

  // смена предмета; шаг и таймер сбрасываем в том же обновлении, чтобы не мелькали старые отметки
  useEffect(() => {
    if (!onScreen) return;
    const t = setInterval(() => {
      const next = (frontRef.current + 1) % examDeck.length;
      frontRef.current = next;
      setFront(next);
      setStep(0);
      setSeconds(durationToSeconds(examDeck[next].duration));
    }, 6500);
    return () => clearInterval(t);
  }, [onScreen]);

  useEffect(() => {
    if (!onScreen) return;
    const t = setInterval(() => setStep((x) => Math.min(x + 1, ROWS * 2 + 4)), 450);
    return () => clearInterval(t);
  }, [onScreen, front]);

  useEffect(() => {
    if (!onScreen) return;
    const t = setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : s)), 1000);
    return () => clearInterval(t);
  }, [onScreen, front]);

  const written = Math.min(step, ROWS);
  const checked = Math.max(0, Math.min(step - ROWS, ROWS));
  const done = step > ROWS * 2;
  const score = answers.filter((a) => a.ok).length;

  return (
    <div
      ref={rootRef}
      className={`w-[17rem] rounded-[26px] bg-white/95 p-4 shadow-[0_30px_60px_-25px_rgba(24,19,47,0.55)] ring-1 ring-white/60 sm:w-[19rem] sm:p-5 ${className}`}
      role="img"
      aria-label={`Бланк ответов: ${blank.subject}, ${blank.exam}, ${blank.duration}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-mono text-[10px] tracking-widest text-muted uppercase">
            {blank.note === "на компьютере" ? "Работа на компьютере" : "Бланк ответов №1"}
          </p>
          <p key={blank.subject} className="mt-1 animate-[fadeUp_.35s_ease-out] font-display text-[16px] leading-tight font-semibold text-violet">
            {blank.subject}
          </p>
        </div>
        <div className="shrink-0 rounded-xl bg-ink px-2.5 py-1.5 text-right">
          <p className="font-mono text-[9px] tracking-widest text-white/50 uppercase">{blank.exam}</p>
          <p className="font-mono text-[15px] leading-tight font-bold text-lime tabular-nums">{format(seconds)}</p>
        </div>
      </div>

      <ul className="mt-4 grid gap-1.5">
        {answers.map((a, i) => (
          <li key={i} className="flex items-center gap-2">
            <span className="w-4 font-mono text-xs font-bold text-muted">{i + 1}</span>
            <span className="flex flex-1 text-[15px] text-violet">
              {Array.from({ length: CELLS }).map((_, k) => (
                <span key={k} className="cell flex-1 border-violet/20!">
                  {i < written ? (a.v[k] ?? "") : ""}
                </span>
              ))}
            </span>
            <span className="grid w-6 place-items-center">
              {i < checked && (
                <svg viewBox="0 0 24 24" className={`size-6 animate-[pop_.25s_ease-out] ${a.ok ? "text-ok" : "text-wrong"}`} aria-hidden>
                  {a.ok ? (
                    <path d="M4 13 L10 18 L20 5" fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
                  ) : (
                    <path d="M6 6 L18 18 M18 6 L6 18" fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" />
                  )}
                </svg>
              )}
            </span>
          </li>
        ))}
      </ul>

      <div className="mt-4 flex items-center justify-between border-t border-dashed border-line pt-3">
        <p className="text-xs leading-snug text-muted">
          Проверяет эксперт
          <br />
          по критериям ФИПИ
        </p>
        <div
          className={`rotate-[-8deg] rounded-xl border-[2.5px] border-violet px-2.5 py-1 text-center text-violet ${
            done ? "scale-100 opacity-100 transition-[opacity,transform] duration-300 ease-out" : "scale-150 opacity-0"
          }`}
        >
          <p className="text-[10px] font-bold tracking-wider uppercase">Проверено</p>
          <p className="font-mono text-lg leading-none font-bold">
            {score}/{ROWS}
          </p>
        </div>
      </div>
    </div>
  );
}
