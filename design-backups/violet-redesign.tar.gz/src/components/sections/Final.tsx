"use client";

import { Clock, FileText, MapPin, MessageCircle, Phone, Send, Users } from "lucide-react";
import { site } from "@/content/site";
import { goal } from "@/lib/metrika";
import { CtaButton, PhoneLink } from "../ui/CtaButton";
import { Squiggle } from "../ui/Decor";
import { LeadForm } from "../ui/LeadForm";
import { MetroIcon } from "../ui/MetroIcon";
import { Logo } from "./Header";

const facts = [
  { icon: Users, title: "Очно, как на экзамене", text: "Рассадка, бланки, тайминг" },
  { icon: MapPin, title: site.landmark, text: `${site.metroWalk} от м. ${site.metroName}` },
  { icon: FileText, title: "Отчёт за 5–7 дней", text: "Баллы и разбор каждой ошибки" },
];

export function CtaForm() {
  return (
    <section id="signup" className="px-3 py-16 sm:px-5 sm:py-24">
      <div className="island-violet relative mx-auto grid max-w-[1360px] overflow-hidden rounded-[32px] text-white sm:rounded-[44px] lg:grid-cols-[1fr_0.95fr]">
        <Squiggle className="absolute top-10 -left-8 w-20 opacity-80" />

        <div className="relative px-6 pt-12 sm:px-10 sm:pt-16 lg:px-14 lg:pb-0">
          <p className="eyebrow text-lime">Запись открыта</p>
          <h2 className="mt-4 text-[2.2rem] leading-[1.02] font-semibold text-balance sm:text-6xl">Узнайте свои баллы до&nbsp;экзамена</h2>
          <p className="mt-5 max-w-md text-lg text-white/80">Оставьте телефон. Администратор перезвонит, подберёт предмет и удобную дату.</p>
          <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-3 text-white/85">
            <PhoneLink className="font-display text-lg font-semibold text-white" />
            <span className="flex items-center gap-2 text-sm">
              <Clock size={16} /> {site.hours}
            </span>
          </div>

          {/* лаймовый круг с ключевыми фактами — вместо фото */}
          <div className="relative mt-8 hidden h-[360px] lg:block">
            <div className="absolute top-[6%] left-[10%] aspect-square w-[70%] rounded-full bg-lime" aria-hidden />
            <ul className="relative grid max-w-sm gap-3 pt-10 pl-6">
              {facts.map((f, i) => (
                <li
                  key={f.title}
                  className="flex items-center gap-3 rounded-3xl bg-white p-3 pr-5 text-ink shadow-[0_20px_40px_-24px_rgba(24,19,47,0.7)]"
                  style={{ transform: `rotate(${[-3, 2, -1.5][i]}deg) translateX(${[0, 36, 12][i]}px)` }}
                >
                  <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-violet text-lime">
                    <f.icon size={20} />
                  </span>
                  <span className="leading-tight">
                    <b className="block font-semibold">{f.title}</b>
                    <span className="text-sm text-muted">{f.text}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="relative px-4 pt-8 pb-4 sm:px-8 sm:pb-8 lg:py-12 lg:pr-12">
          <div className="rounded-[32px] bg-white p-6 text-ink shadow-[0_30px_60px_-30px_rgba(24,19,47,0.6)] sm:p-8">
            <p className="text-2xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
              Записаться на пробник
            </p>
            <p className="mt-1.5 text-sm text-muted">Перезвоним в течение 15 минут в рабочее время.</p>
            <div className="mt-6">
              <LeadForm source="final" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Contacts() {
  const { lat, lon } = site.geo;
  return (
    <section id="contacts" className="px-3 pb-16 sm:px-5 sm:pb-24">
      <div className="mx-auto grid max-w-7xl gap-4 px-2 sm:px-6 lg:grid-cols-[0.8fr_1.2fr] lg:gap-5">
        <div className="rounded-[36px] bg-white p-7 ring-1 ring-line sm:p-9">
          <p className="eyebrow text-violet">Контакты</p>
          <h2 className="mt-4 text-3xl font-semibold sm:text-4xl">Как нас найти</h2>
          <ul className="mt-8 grid gap-4">
            <li className="flex gap-4">
              <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-violet text-lime">
                <MapPin size={20} />
              </span>
              <span>
                <b className="block font-semibold">{site.landmark}</b>
                <span className="text-muted">
                  {site.address}, {site.city}
                </span>
              </span>
            </li>
            <li className="flex items-center gap-4 rounded-2xl bg-lime/60 p-3">
              <MetroIcon className="size-11" />
              <span>
                <b className="block font-semibold">
                  {site.metroWalk} от м. {site.metroName}
                </b>
                <span className="text-sm text-ink/70">Выход к Каменноостровскому проспекту</span>
              </span>
            </li>
            <li className="flex items-center gap-4">
              <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-violet-soft text-violet">
                <Phone size={20} />
              </span>
              <PhoneLink withIcon={false} className="font-display text-lg font-semibold" />
            </li>
            <li className="flex items-center gap-4">
              <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-violet-soft text-violet">
                <Clock size={20} />
              </span>
              <span className="text-muted">{site.hours}</span>
            </li>
          </ul>
          <div className="mt-8 flex flex-wrap gap-2.5">
            <a
              href={site.telegram}
              target="_blank"
              rel="noopener"
              onClick={() => goal("click_messenger", { m: "tg" })}
              className="inline-flex min-h-12 items-center gap-2 rounded-full bg-cream px-5 font-medium transition hover:bg-violet-soft"
            >
              <Send size={18} className="text-violet" /> Telegram
            </a>
            <a
              href={site.max}
              target="_blank"
              rel="noopener"
              onClick={() => goal("click_messenger", { m: "max" })}
              className="inline-flex min-h-12 items-center gap-2 rounded-full bg-cream px-5 font-medium transition hover:bg-violet-soft"
            >
              <MessageCircle size={18} className="text-violet" /> MAX
            </a>
          </div>
        </div>
        <div className="min-h-[380px] overflow-hidden rounded-[36px] bg-violet-soft ring-1 ring-line">
          <iframe
            title={`Карта: ${site.address}`}
            src={`https://yandex.ru/map-widget/v1/?ll=${lon}%2C${lat}&z=17&pt=${lon}%2C${lat}%2Cpm2rdm`}
            className="h-full min-h-[380px] w-full border-0"
            loading="lazy"
            allowFullScreen
          />
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  const { legal } = site;
  return (
    <footer className="px-3 pb-24 sm:px-5 sm:pb-5">
      <div className="mx-auto max-w-[1360px] rounded-[32px] bg-violet-deep px-6 pt-12 pb-8 text-white/70 sm:rounded-[44px] sm:px-10 lg:px-14">
        <div className="flex flex-col gap-8 border-b border-white/10 pb-10 md:flex-row md:items-center md:justify-between">
          <Logo light />
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <PhoneLink className="font-display font-semibold text-white" />
            <CtaButton source="footer">Записаться</CtaButton>
          </div>
        </div>
        <div className="grid gap-6 pt-8 text-sm md:grid-cols-2">
          <div className="grid gap-1">
            <p>{legal.entity}</p>
            <p>
              ИНН {legal.inn} · ОГРН{legal.ogrn.length > 13 ? "ИП" : ""} {legal.ogrn}
            </p>
            <p>
              {site.city}, {site.address}
            </p>
            <a href="/privacy/" className="mt-2 underline underline-offset-2 hover:text-white">
              Политика обработки персональных данных
            </a>
          </div>
          <p className="text-white/50 md:text-right">
            Пробные экзамены являются платной образовательной услугой. {site.name} не является пунктом проведения экзаменов и
            не связан с ФИПИ и Рособрнадзором. Результат пробника не влияет на официальные результаты ЕГЭ и ОГЭ.
            <br />© {new Date().getFullYear()} {site.name}
          </p>
        </div>
      </div>
    </footer>
  );
}

export function MobileCtaBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 flex gap-2 bg-white/95 p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] shadow-[0_-10px_30px_-20px_rgba(24,19,47,0.5)] sm:hidden">
      <a
        href={site.phoneHref}
        onClick={() => goal("click_phone", { source: "mobile_bar" })}
        aria-label={`Позвонить ${site.phone}`}
        className="grid size-14 shrink-0 place-items-center rounded-full bg-violet-soft text-violet"
      >
        <Phone size={22} />
      </a>
      <CtaButton source="mobile_bar" className="flex-1">
        Записаться
      </CtaButton>
    </div>
  );
}
