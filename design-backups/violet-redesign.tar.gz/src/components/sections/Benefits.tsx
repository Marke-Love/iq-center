import { BarChart3, ClipboardCheck, FileText, ShieldCheck } from "lucide-react";
import { Squiggle } from "../ui/Decor";
import { Reveal, SectionHead } from "../ui/Reveal";

const items = [
  { icon: BarChart3, title: "Баллы по шкале ФИПИ", text: "Первичные и тестовые баллы, такие же, как в официальных результатах." },
  { icon: ClipboardCheck, title: "Разбор каждой ошибки", text: "Что не так, почему сняли баллы и как оформить правильно." },
  {
    icon: ShieldCheck,
    title: "Уверенность",
    text: "Процедура уже знакома, поэтому на экзамене все силы уйдут на решение задач, а не на стресс.",
  },
];

const report = ["Реальный уровень знаний", "Предполагаемый результат на экзамене", "Слабые места, которые можно отработать"];

export function Benefits() {
  return (
    <section id="result" className="px-3 sm:px-5">
      <div className="mx-auto max-w-[1360px] rounded-[32px] bg-white px-5 py-14 ring-1 ring-line sm:rounded-[44px] sm:px-10 sm:py-20 lg:px-14">
        <div className="grid items-center gap-12 lg:grid-cols-[1fr_0.95fr] lg:gap-16">
          <div>
            <SectionHead
              eyebrow="Что получите"
              title={
                <>
                  Не просто оценку, а <span className="text-violet">карту ошибок</span>
                </>
              }
              lead="После проведения экзамена у ученика и родителей есть ясная картина: на каком уровне подготовленности он находится и что делать дальше."
            />
            <ul className="mt-10 grid gap-4">
              {items.map((it, i) => (
                <Reveal key={it.title} delay={i * 0.06}>
                  <li className="flex gap-4 rounded-[24px] bg-cream p-5">
                    <div className="grid size-12 shrink-0 place-items-center rounded-2xl bg-violet text-lime">
                      <it.icon size={22} />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">{it.title}</h3>
                      <p className="mt-1 text-muted">{it.text}</p>
                    </div>
                  </li>
                </Reveal>
              ))}
            </ul>
          </div>

          {/* отчёт: что ученик и родители получат на руки */}
          <Reveal delay={0.1}>
            <div className="island-violet relative overflow-hidden rounded-[36px] p-5 text-white sm:p-7">
              <Squiggle className="absolute -top-8 -right-4 w-16 rotate-45 opacity-80" />
              <div className="relative">
                {/* образец отчёта: баллы и выполнение по заданиям */}
                <div className="rounded-[26px] bg-white p-5 text-ink sm:p-6" role="img" aria-label="Пример отчёта: баллы и выполнение по заданиям">
                  <div className="flex items-center justify-between gap-3">
                    <span className="inline-flex items-center gap-2 text-sm font-semibold">
                      <span className="grid size-8 place-items-center rounded-full bg-violet text-lime">
                        <FileText size={15} />
                      </span>
                      Отчёт по пробнику
                    </span>
                    <span className="rounded-full bg-cream px-3 py-1 text-xs text-muted">пример</span>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <div className="rounded-2xl bg-cream p-3.5">
                      <p className="text-xs text-muted">Первичный балл</p>
                      <p className="mt-1 font-display text-3xl leading-none font-semibold">
                        14<span className="text-base text-muted">/32</span>
                      </p>
                    </div>
                    <div className="rounded-2xl bg-violet p-3.5 text-white">
                      <p className="text-xs text-white/70">Тестовый балл</p>
                      <p className="mt-1 font-display text-3xl leading-none font-semibold text-lime">74</p>
                    </div>
                  </div>
                  <p className="mt-4 text-xs font-semibold tracking-wide text-muted uppercase">Задания</p>
                  <div className="mt-2 grid grid-cols-10 gap-1.5">
                    {[1, 1, 1, 0, 1, 1, 1, 1, 0.5, 1, 1, 0, 1, 0.5, 0, 1, 0.5, 0, 1, 0].map((v, i) => (
                      <span
                        key={i}
                        title={`Задание ${i + 1}`}
                        className={`aspect-square rounded-md ${v === 1 ? "bg-ok" : v > 0 ? "bg-lavender" : "bg-wrong/80"}`}
                      />
                    ))}
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap items-end gap-x-4 gap-y-2">
                  <p className="flex items-baseline gap-2">
                    <span className="font-display text-6xl leading-none font-semibold text-lime sm:text-7xl">5–7</span>
                    <span className="text-xl font-semibold">дней</span>
                  </p>
                  <p className="max-w-xs pb-1 text-white/80">и у вас на руках полный развёрнутый отчёт с результатом и всеми ошибками</p>
                </div>

                <p className="mt-5 text-white/75">
                  На его основе вы увидите реальную картину уровня знаний, поймёте слабые места и сможете отработать их заранее.
                </p>

                <ul className="mt-6 flex flex-wrap gap-2">
                  {report.map((r) => (
                    <li key={r} className="rounded-full bg-white/12 px-4 py-2 text-sm font-medium ring-1 ring-white/20">
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
