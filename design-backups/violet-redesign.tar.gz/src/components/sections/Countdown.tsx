import { CtaButton } from "../ui/CtaButton";
import { Squiggle } from "../ui/Decor";
import { Reveal, SectionHead } from "../ui/Reveal";

// «до» и «после» — про состояние ученика, а не про обещанные баллы
const before = [
  "Настоящий бланк видел только на картинке",
  "Не знает, на что уходит время на экзамене",
  "Оформляет ответы как привык, а не по критериям",
  "О своём реальном уровне судит по домашним работам",
];

const after = [
  "Заполнял бланки по регламенту, рука уже помнит",
  "Знает, на каких заданиях теряет минуты",
  "Понимает, за что эксперт снимает баллы",
  "Есть баллы по шкале ФИПИ и план, что подтянуть",
];

export function Countdown() {
  return (
    <section className="px-3 sm:px-5">
      <div className="relative mx-auto max-w-[1360px] overflow-hidden rounded-[32px] bg-lime px-5 py-14 text-ink sm:rounded-[44px] sm:px-10 sm:py-20 lg:px-14">
        <Squiggle className="absolute -top-12 right-10 hidden w-24 rotate-90 lg:block" color="var(--color-violet)" />
        <div className="relative">
          <SectionHead
            eyebrow="Пока есть время"
            title={<>Экзамен ближе, чем кажется</>}
            lead="Первый раз увидеть бланк и услышать «время пошло» можно у нас. Или в день, когда результат идёт в аттестат."
          />

          <div className="mt-10 grid gap-4 sm:mt-12 lg:grid-cols-2 lg:gap-5">
            <Reveal>
              <div className="h-full rounded-[32px] bg-white/60 p-7 sm:p-8">
                <p className="text-sm font-semibold tracking-wide text-muted uppercase">Без пробника</p>
                <ul className="mt-5 grid gap-3.5">
                  {before.map((t) => (
                    <li key={t} className="flex gap-3 text-ink/75">
                      <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-ink/10 text-ink/60">
                        <svg viewBox="0 0 24 24" className="size-3" aria-hidden>
                          <path d="M6 6 L18 18 M18 6 L6 18" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
                        </svg>
                      </span>
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>

            <Reveal delay={0.08}>
              <div className="island-violet h-full rounded-[32px] p-7 text-white sm:p-8">
                <p className="text-sm font-semibold tracking-wide text-lime uppercase">После пробника</p>
                <ul className="mt-5 grid gap-3.5">
                  {after.map((t) => (
                    <li key={t} className="flex gap-3">
                      <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-lime text-ink">
                        <svg viewBox="0 0 24 24" className="size-3.5" aria-hidden>
                          <path d="M4 13 L10 18 L20 5" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </span>
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          </div>

          <Reveal className="mt-10 flex flex-col items-start gap-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="max-w-xl text-2xl leading-snug font-semibold tracking-tight sm:text-3xl" style={{ fontFamily: "var(--font-display)" }}>
              Пусть первый экзамен пройдёт там, где ошибка ничего не стоит
            </p>
            <CtaButton source="countdown" variant="violet" className="w-full shrink-0 sm:w-auto">
              Записаться на пробник
            </CtaButton>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
