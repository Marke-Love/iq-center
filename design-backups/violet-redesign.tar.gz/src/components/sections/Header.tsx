"use client";

import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { site } from "@/content/site";
import { CtaButton, PhoneLink } from "../ui/CtaButton";

const nav = [
  { href: "#why", label: "Зачем пробник" },
  { href: "#result", label: "Что получите" },
  { href: "#prices", label: "Стоимость" },
  { href: "#faq", label: "Вопросы" },
  { href: "#contacts", label: "Контакты" },
];

// Подсвечиваем пункт меню того блока, который сейчас перед глазами
function useActiveSection() {
  const [active, setActive] = useState("");
  useEffect(() => {
    const els = nav.map((n) => document.querySelector(n.href)).filter((el): el is Element => !!el);
    const io = new IntersectionObserver(
      (entries) => {
        const hit = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (hit) setActive("#" + hit.target.id);
      },
      // «текущий» блок — тот, что пересекает полосу чуть ниже шапки
      { rootMargin: "-30% 0px -60% 0px" },
    );
    els.forEach((el) => io.observe(el));
    const onTop = () => window.scrollY < 200 && setActive("");
    window.addEventListener("scroll", onTop, { passive: true });
    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onTop);
    };
  }, []);
  return active;
}

export function Logo({ light }: { light?: boolean }) {
  return (
    <a href="#top" className="flex items-center gap-2.5" aria-label={`${site.tagline}, наверх`}>
      <span className="grid size-10 place-items-center rounded-2xl bg-violet font-display text-sm font-bold text-lime">IQ</span>
      <span className={`font-display text-[15px] leading-[1.1] font-semibold tracking-tight ${light ? "text-white" : "text-ink"}`}>
        Пробные
        <br />
        <span className={light ? "text-lime" : "text-violet"}>ЕГЭ и ОГЭ</span>
      </span>
    </a>
  );
}

export function Header() {
  const [open, setOpen] = useState(false);
  const active = useActiveSection();

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-5 sm:pt-4">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 rounded-full bg-white/95 py-2 pr-2 pl-4 shadow-[var(--shadow-soft)] ring-1 ring-line sm:pl-5">
        <Logo />

        <nav className="hidden items-center gap-0.5 rounded-full bg-cream p-1 text-[14px] font-medium lg:flex" aria-label="Основное меню">
          {nav.map((n) => (
            <a
              key={n.href}
              href={n.href}
              aria-current={active === n.href ? "true" : undefined}
              className={`rounded-full px-3.5 py-2 whitespace-nowrap transition ${
                active === n.href ? "bg-white text-violet shadow-sm" : "text-muted hover:text-ink"
              }`}
            >
              {n.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <span className="hidden px-2 md:block lg:hidden xl:block">
            <PhoneLink className="font-display text-sm font-semibold" />
          </span>
          <span className="hidden sm:block">
            <CtaButton source="header" variant="violet" className="min-h-12! py-1! pl-5! text-sm! [&>span:last-child]:size-9!">
              Записаться
            </CtaButton>
          </span>
          <button
            className="grid size-12 place-items-center rounded-full bg-cream lg:hidden"
            aria-label={open ? "Закрыть меню" : "Открыть меню"}
            aria-expanded={open}
            onClick={() => setOpen(!open)}
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {open && (
        <nav
          className="mx-auto mt-2 max-w-7xl rounded-[28px] bg-white p-3 shadow-[var(--shadow-soft)] ring-1 ring-line lg:hidden"
          aria-label="Мобильное меню"
        >
          {nav.map((n) => (
            <a
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className={`block rounded-2xl px-4 py-3.5 font-display text-lg font-semibold ${active === n.href ? "bg-violet-soft text-violet" : ""}`}
            >
              {n.label}
            </a>
          ))}
          <PhoneLink className="mt-2 px-4 py-3 font-display text-lg font-semibold text-violet" />
        </nav>
      )}
    </header>
  );
}
