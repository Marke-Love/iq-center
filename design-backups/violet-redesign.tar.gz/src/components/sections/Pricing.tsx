import { pricing, site } from "@/content/site";
import { CtaButton, PhoneLink } from "../ui/CtaButton";
import { Loop } from "../ui/Decor";
import { Reveal, SectionHead } from "../ui/Reveal";

export function Pricing() {
  return (
    <section id="prices" className="px-3 py-16 sm:px-5 sm:py-24">
      <div className="mx-auto max-w-7xl px-2 sm:px-6">
        <SectionHead
          eyebrow="Стоимость"
          title="Одна запись, и всё включено"
          lead="В цену уже входят сам экзамен, проверка работы экспертом и разбор ошибок. Ничего доплачивать не нужно."
        />

        <Reveal className="mt-10 sm:mt-14">
          <div className="grid gap-4 lg:grid-cols-[0.9fr_1.1fr] lg:gap-5">
            {/* цена и запись — главное действие блока */}
            <div className="island-violet relative overflow-hidden rounded-[36px] p-7 text-white sm:p-10">
              <Loop className="absolute -right-10 -bottom-6 w-60 opacity-50" color="rgba(217,242,75,0.7)" />
              <div className="relative">
                <p className="text-sm font-medium tracking-wide text-white/70 uppercase">{pricing.unit}</p>
                <p className="mt-3 flex items-start gap-1 font-display leading-none font-semibold">
                  <span className="text-7xl text-lime sm:text-8xl">{pricing.price.toLocaleString("ru-RU")}</span>
                  <span className="mt-2 text-3xl sm:text-4xl">₽</span>
                </p>
                <p className="mt-5 max-w-sm text-white/80">Выберите предмет и&nbsp;дату. Остальное за&nbsp;нами.</p>
                <CtaButton source="prices" className="mt-8 w-full min-h-16! text-lg! sm:w-auto sm:pr-2! sm:pl-8!">
                  Записаться на пробник
                </CtaButton>
                <p className="mt-5 text-sm text-white/70">
                  Или позвоните: <PhoneLink withIcon={false} className="font-display font-semibold text-white" />
                </p>
              </div>
            </div>

            {/* состав услуги */}
            <div className="rounded-[36px] bg-white p-7 ring-1 ring-line sm:p-10">
              <h3 className="text-2xl font-semibold">В пробник входит</h3>
              <ul className="mt-6 grid gap-3">
                {pricing.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 rounded-2xl bg-cream px-4 py-3.5">
                    <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-violet text-lime">
                      <svg viewBox="0 0 24 24" className="size-3.5" aria-hidden>
                        <path d="M4 13 L10 18 L20 5" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-6 text-sm text-muted">{pricing.note}</p>
              <p className="mt-1 text-sm text-muted">
                {site.landmark}, {site.metroWalk} от м. {site.metroName}
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
