import { Reveal, SectionHead } from "../ui/Reveal";

const items = [
  {
    problem: "Волнение в незнакомой обстановке",
    fix: "Школьник проходит всю процедуру заранее: вход по списку, отсутствие телефонов, инструктаж. На экзамене всё уже знакомо.",
  },
  {
    problem: "Растерялся на новом типе задания",
    fix: "Задания составлены с учётом всех нововведений. Если в формате что-то изменилось, ученик встретит это у нас, а не впервые на экзамене.",
  },
  {
    problem: "Ошибки в заполнении бланков",
    fix: "Заполняет настоящие бланки ответов. Проверяющий отметит неправильное написание цифр, единиц и переносы.",
  },
  {
    problem: "Решено верно, но оформлено не по критериям",
    fix: "Развёрнутые ответы оцениваются строго по критериям ФИПИ. Видно, за что снимают баллы.",
  },
];

export function Pain() {
  return (
    <section id="why" className="px-3 py-16 sm:px-5 sm:py-24">
      <div className="mx-auto max-w-7xl px-2 sm:px-6">
        <SectionHead
          eyebrow="Зачем нужен пробник"
          title={
            <>
              Баллы теряют не только из‑за <span className="rounded-2xl bg-lime px-2 sm:px-3">знаний</span>
            </>
          }
          lead="Даже хорошо подготовленные ученики ошибаются на самом экзамене. Причины: обстановка, время, нервозность и страх. Всё это можно отработать заранее."
        />
        <div className="mt-10 grid gap-4 sm:mt-14 sm:gap-5 md:grid-cols-2">
          {items.map((it, i) => (
            <Reveal key={it.problem} delay={i * 0.06}>
              <article className="group flex h-full flex-col rounded-[32px] bg-white p-6 shadow-[var(--shadow-soft)] ring-1 ring-line transition duration-300 hover:-translate-y-1 sm:p-8">
                <div className="flex items-start gap-4">
                  <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-violet-soft text-violet transition group-hover:bg-violet group-hover:text-lime">
                    <svg viewBox="0 0 24 24" className="size-5" aria-hidden>
                      <path d="M6 6 L18 18 M18 6 L6 18" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                    </svg>
                  </span>
                  <h3 className="pt-2 text-xl leading-snug font-semibold sm:text-[1.4rem]">{it.problem}</h3>
                </div>
                <p className="mt-5 flex gap-3 border-t border-dashed border-line pt-5 text-muted">
                  <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-lime text-ink">
                    <svg viewBox="0 0 24 24" className="size-3.5" aria-hidden>
                      <path d="M4 13 L10 18 L20 5" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  {it.fix}
                </p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
