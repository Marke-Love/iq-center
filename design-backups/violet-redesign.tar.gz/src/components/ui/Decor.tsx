// Декор в духе референса: мягкие завитки и рукописный овал вокруг слова.

export function Squiggle({ className = "", color = "var(--color-lime)" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 120 220" className={`pointer-events-none ${className}`} fill="none" aria-hidden>
      <path
        d="M60 10 C 10 40, 110 70, 60 105 S 10 175, 60 210"
        stroke={color}
        strokeWidth="18"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Loop({ className = "", color = "var(--color-lavender)" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 200 120" className={`pointer-events-none ${className}`} fill="none" aria-hidden>
      <path
        d="M10 90 C 40 20, 90 10, 100 55 C 108 95, 60 100, 70 60 C 80 25, 150 20, 190 70"
        stroke={color}
        strokeWidth="12"
        strokeLinecap="round"
      />
    </svg>
  );
}

// Слово, обведённое от руки лаймовым овалом
export function Circled({ children, color = "var(--color-lime)" }: { children: React.ReactNode; color?: string }) {
  return (
    <span className="relative inline-block whitespace-nowrap">
      <span className="relative z-10">{children}</span>
      <svg
        viewBox="0 0 400 140"
        preserveAspectRatio="none"
        className="pointer-events-none absolute -inset-x-[7%] -inset-y-[22%] h-[144%] w-[114%]"
        fill="none"
        aria-hidden
      >
        <path
          d="M30 80 C 20 30, 180 8, 300 16 C 390 22, 400 80, 330 108 C 250 138, 80 136, 34 104 C 14 90, 22 66, 60 48"
          stroke={color}
          strokeWidth="6"
          strokeLinecap="round"
        />
      </svg>
    </span>
  );
}
