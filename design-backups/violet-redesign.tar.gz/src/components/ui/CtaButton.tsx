"use client";

import { ArrowUpRight, Phone } from "lucide-react";
import { site } from "@/content/site";
import { goal } from "@/lib/metrika";
import { useLead } from "./LeadProvider";

type Variant = "lime" | "violet" | "white";

type Props = {
  children: React.ReactNode;
  source: string;
  subject?: string;
  exam?: string;
  variant?: Variant;
  className?: string;
};

// Кнопка-таблетка с круглой стрелкой справа, как «Read more ↗» в референсе
const pill: Record<Variant, string> = {
  lime: "bg-lime text-ink hover:bg-[#cfe83a]",
  violet: "bg-violet text-white hover:bg-violet-deep",
  white: "bg-white text-ink hover:bg-violet-soft",
};
const dot: Record<Variant, string> = {
  lime: "bg-ink text-lime",
  violet: "bg-lime text-ink",
  white: "bg-violet text-white",
};

export function CtaButton({ children, source, subject, exam, variant = "lime", className = "" }: Props) {
  const open = useLead();
  return (
    <button
      type="button"
      onClick={() => {
        goal("click_cta", { source });
        open({ source, subject, exam });
      }}
      className={`group inline-flex min-h-14 items-center justify-between gap-4 rounded-full py-1.5 pr-1.5 pl-6 font-display text-[15px] font-semibold tracking-tight transition ${pill[variant]} ${className}`}
    >
      <span>{children}</span>
      <span className={`grid size-11 shrink-0 place-items-center rounded-full transition-transform duration-300 group-hover:rotate-45 ${dot[variant]}`}>
        <ArrowUpRight size={20} strokeWidth={2.4} />
      </span>
    </button>
  );
}

export function PhoneLink({ className = "", withIcon = true }: { className?: string; withIcon?: boolean }) {
  return (
    <a href={site.phoneHref} onClick={() => goal("click_phone")} className={`inline-flex items-center gap-2 whitespace-nowrap ${className}`}>
      {withIcon && <Phone size={17} />}
      {site.phone}
    </a>
  );
}
