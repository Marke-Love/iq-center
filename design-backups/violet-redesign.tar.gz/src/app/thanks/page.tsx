import type { Metadata } from "next";
import { ArrowLeft } from "lucide-react";
import { site } from "@/content/site";

export const metadata: Metadata = { title: "Заявка принята | " + site.name, robots: { index: false } };

export default function Thanks() {
  return (
    <main className="island-violet grid min-h-svh place-items-center px-4 py-16">
      <div className="w-full max-w-lg rounded-[36px] bg-white p-8 text-center shadow-[var(--shadow-soft)] sm:p-12">
        <div className="mx-auto w-fit rotate-[-6deg] rounded-full bg-lime px-5 py-2 text-ink">
          <p className="text-sm font-bold tracking-wider uppercase">Заявка принята</p>
        </div>
        <h1 className="mt-8 text-3xl leading-tight font-semibold">Спасибо! Скоро перезвоним</h1>
        <p className="mt-4 text-lg text-muted">
          Администратор свяжется с вами в течение 15 минут в рабочее время ({site.hours.toLowerCase()}) и подберёт дату пробника.
        </p>
        <p className="mt-6 text-muted">
          Срочный вопрос? <a href={site.phoneHref} className="font-semibold text-violet">{site.phone}</a>
        </p>
        <a href="/" className="mt-8 inline-flex min-h-12 items-center gap-2 rounded-full bg-violet px-6 font-display text-sm font-semibold text-white">
          <ArrowLeft size={18} /> На главную
        </a>
      </div>
    </main>
  );
}
